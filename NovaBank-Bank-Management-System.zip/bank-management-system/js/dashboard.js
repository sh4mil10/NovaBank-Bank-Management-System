
document.addEventListener('DOMContentLoaded',()=>{
const u=requireAuth();if(!u)return;const db=getDB(),acc=db.accounts.filter(a=>a.userId===u.id),tx=db.transactions.filter(t=>t.userId===u.id);
document.getElementById('greeting').textContent=`Good Evening, ${u.name.split(' ')[0]} 👋`;
document.getElementById('balance').textContent=money(acc.reduce((s,a)=>s+a.balance,0));
document.getElementById('acctCount').textContent=acc.length;
document.getElementById('txCount').textContent=tx.length;
document.getElementById('recent').innerHTML=tx.slice(0,5).map(t=>`<div class="activity-item"><div class="activity-icon">${icon(t.type==='Credit'?'arrow-down':'arrow-up')}</div><div class="activity-main"><strong>${esc(t.desc)}</strong><small>${t.date} · ${t.time}</small></div><span class="${t.type==='Credit'?'amount-credit':'amount-debit'}">${t.type==='Credit'?'+':'-'}${money(t.amount)}</span></div>`).join('');
chart('moneyChart','line',['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],[
{label:'Income',data:[42000,12000,0,75000,18000,5000,12000],borderWidth:3,tension:.4},
{label:'Expenses',data:[5000,8400,2350,12000,5000,7600,4200],borderWidth:3,tension:.4}
]);
let unread=db.notifications.filter(n=>n.userId===u.id&&!n.read).length;document.getElementById('notifCount').textContent=unread;
});
