
const DBKEY='novaBankDB';
const seed={
 users:[
  {id:'CUS1001',name:'Niranjan M S',email:'customer@bank.com',password:'Customer@123',role:'customer',phone:'+91 98765 43210',address:'Kollam, Kerala',status:'Active'},
  {id:'ADM001',name:'Bank Administrator',email:'admin@bank.com',password:'Admin@123',role:'admin',phone:'+91 90000 00000',address:'Chennai, Tamil Nadu',status:'Active'},
  {id:'CUS1002',name:'Rahul Kumar',email:'rahul@bank.com',password:'Rahul@123',role:'customer',phone:'+91 91234 56789',address:'Kochi, Kerala',status:'Active'},
  {id:'CUS1003',name:'Ananya Nair',email:'ananya@bank.com',password:'Ananya@123',role:'customer',phone:'+91 99887 77665',address:'Bengaluru, Karnataka',status:'Active'},
  {id:'CUS1004',name:'Arjun Menon',email:'arjun@bank.com',password:'Arjun@123',role:'customer',phone:'+91 90909 12345',address:'Trivandrum, Kerala',status:'Suspended'},
  {id:'CUS1005',name:'Meera Krishnan',email:'meera@bank.com',password:'Meera@123',role:'customer',phone:'+91 93456 77889',address:'Coimbatore, Tamil Nadu',status:'Active'},
  {id:'CUS1006',name:'Vikram Shah',email:'vikram@bank.com',password:'Vikram@123',role:'customer',phone:'+91 98888 11122',address:'Mumbai, Maharashtra',status:'Active'},
  {id:'CUS1007',name:'Priya Das',email:'priya@bank.com',password:'Priya@123',role:'customer',phone:'+91 97654 32109',address:'Bhubaneswar, Odisha',status:'Active'},
  {id:'CUS1008',name:'Aditya Rao',email:'aditya@bank.com',password:'Aditya@123',role:'customer',phone:'+91 95555 11223',address:'Hyderabad, Telangana',status:'Active'}
 ],
 accounts:[
  {id:'ACC001',userId:'CUS1001',type:'Savings',number:'XXXX XXXX 4521',balance:245680.50,interest:4.5,status:'Active'},
  {id:'ACC002',userId:'CUS1001',type:'Current',number:'XXXX XXXX 8834',balance:580200,interest:3.2,status:'Active'},
  {id:'ACC003',userId:'CUS1002',type:'Savings',number:'XXXX XXXX 7312',balance:154320,interest:4.5,status:'Active'},
  {id:'ACC004',userId:'CUS1003',type:'Savings',number:'XXXX XXXX 1844',balance:326700,interest:4.5,status:'Active'},
  {id:'ACC005',userId:'CUS1004',type:'Current',number:'XXXX XXXX 6109',balance:89200,interest:3.2,status:'Suspended'},
  {id:'ACC006',userId:'CUS1005',type:'Savings',number:'XXXX XXXX 2991',balance:412500,interest:4.5,status:'Active'},
  {id:'ACC007',userId:'CUS1006',type:'Savings',number:'XXXX XXXX 5518',balance:205400,interest:4.5,status:'Active'},
  {id:'ACC008',userId:'CUS1007',type:'Savings',number:'XXXX XXXX 9022',balance:178900,interest:4.5,status:'Active'},
  {id:'ACC009',userId:'CUS1008',type:'Current',number:'XXXX XXXX 7733',balance:640100,interest:3.2,status:'Active'}
 ],
 transactions:[
  {id:'TXN982734',userId:'CUS1001',desc:'Salary',type:'Credit',amount:75000,status:'Completed',balance:245680.50,date:'2026-09-29',time:'19:42'},
  {id:'TXN982733',userId:'CUS1001',desc:'Amazon',type:'Credit',amount:2500,status:'Completed',balance:170680.50,date:'2026-09-28',time:'16:10'},
  {id:'TXN982732',userId:'CUS1001',desc:'Swiggy',type:'Debit',amount:640,status:'Completed',balance:168180.50,date:'2026-09-27',time:'21:05'},
  {id:'TXN982731',userId:'CUS1001',desc:'Electricity Bill',type:'Debit',amount:2350,status:'Completed',balance:168820.50,date:'2026-09-26',time:'11:20'},
  {id:'TXN982730',userId:'CUS1001',desc:'UPI — Rahul Kumar',type:'Debit',amount:5000,status:'Completed',balance:171170.50,date:'2026-09-25',time:'18:33'},
  {id:'TXN982729',userId:'CUS1001',desc:'Freelance Payment',type:'Credit',amount:18000,status:'Completed',balance:176170.50,date:'2026-09-23',time:'10:12'},
  {id:'TXN982728',userId:'CUS1001',desc:'Netflix',type:'Debit',amount:649,status:'Completed',balance:158170.50,date:'2026-09-22',time:'20:01'},
  {id:'TXN982727',userId:'CUS1001',desc:'UPI — Cafe',type:'Debit',amount:420,status:'Pending',balance:158819.50,date:'2026-09-21',time:'14:45'},
  {id:'TXN982726',userId:'CUS1002',desc:'Salary',type:'Credit',amount:68000,status:'Completed',balance:154320,date:'2026-09-29',time:'09:10'},
  {id:'TXN982725',userId:'CUS1003',desc:'Rent',type:'Debit',amount:22000,status:'Completed',balance:326700,date:'2026-09-28',time:'08:10'},
  {id:'TXN982724',userId:'CUS1005',desc:'UPI — Merchant',type:'Debit',amount:1850,status:'Completed',balance:412500,date:'2026-09-27',time:'12:30'},
  {id:'TXN982723',userId:'CUS1006',desc:'Transfer Received',type:'Credit',amount:12000,status:'Completed',balance:205400,date:'2026-09-26',time:'16:45'},
  {id:'TXN982722',userId:'CUS1007',desc:'Shopping',type:'Debit',amount:7990,status:'Completed',balance:178900,date:'2026-09-25',time:'17:20'},
  {id:'TXN982721',userId:'CUS1008',desc:'Vendor Payment',type:'Debit',amount:34000,status:'Completed',balance:640100,date:'2026-09-24',time:'13:05'},
  {id:'TXN982720',userId:'CUS1002',desc:'UPI — Food',type:'Debit',amount:780,status:'Failed',balance:154320,date:'2026-09-23',time:'19:15'},
  {id:'TXN982719',userId:'CUS1003',desc:'Interest Credit',type:'Credit',amount:1450,status:'Completed',balance:348700,date:'2026-09-22',time:'09:00'},
  {id:'TXN982718',userId:'CUS1005',desc:'Salary',type:'Credit',amount:72000,status:'Completed',balance:414350,date:'2026-09-21',time:'08:55'},
  {id:'TXN982717',userId:'CUS1006',desc:'Insurance',type:'Debit',amount:4600,status:'Completed',balance:193400,date:'2026-09-20',time:'10:10'},
  {id:'TXN982716',userId:'CUS1007',desc:'Transfer Received',type:'Credit',amount:9000,status:'Completed',balance:186890,date:'2026-09-19',time:'14:22'},
  {id:'TXN982715',userId:'CUS1008',desc:'Office Supplies',type:'Debit',amount:5200,status:'Completed',balance:674100,date:'2026-09-18',time:'15:45'}
 ],
 loans:[
  {id:'LN001',userId:'CUS1001',category:'Education Loan',amount:500000,rate:8.5,tenure:60,status:'Under Review'},
  {id:'LN002',userId:'CUS1002',category:'Personal Loan',amount:250000,rate:11.5,tenure:36,status:'Approved'},
  {id:'LN003',userId:'CUS1003',category:'Home Loan',amount:4500000,rate:8.1,tenure:240,status:'Pending'},
  {id:'LN004',userId:'CUS1005',category:'Vehicle Loan',amount:900000,rate:9.2,tenure:60,status:'Approved'},
  {id:'LN005',userId:'CUS1006',category:'Personal Loan',amount:180000,rate:12,tenure:24,status:'Rejected'},
  {id:'LN006',userId:'CUS1007',category:'Education Loan',amount:350000,rate:8.5,tenure:60,status:'Pending'}
 ],
 cards:[
  {id:'CARD001',userId:'CUS1001',last4:'4521',holder:'NIRANJAN M S',status:'Active',limit:100000},
  {id:'CARD002',userId:'CUS1002',last4:'7312',holder:'RAHUL KUMAR',status:'Active',limit:75000},
  {id:'CARD003',userId:'CUS1003',last4:'1844',holder:'ANANYA NAIR',status:'Frozen',limit:120000},
  {id:'CARD004',userId:'CUS1005',last4:'2991',holder:'MEERA KRISHNAN',status:'Active',limit:90000},
  {id:'CARD005',userId:'CUS1006',last4:'5518',holder:'VIKRAM SHAH',status:'Active',limit:150000}
 ],
 notifications:[
  {id:1,userId:'CUS1001',text:'₹75,000 salary credited.',time:'2 hours ago',read:false},
  {id:2,userId:'CUS1001',text:'Your transfer of ₹5,000 was successful.',time:'Yesterday',read:false},
  {id:3,userId:'CUS1001',text:'Your loan application is under review.',time:'2 days ago',read:true},
  {id:4,userId:'CUS1001',text:'Your card payment of ₹1,250 was completed.',time:'3 days ago',read:true}
 ],
 settings:{theme:'light',notifications:true}
};
function getDB(){let x=localStorage.getItem(DBKEY);if(!x){localStorage.setItem(DBKEY,JSON.stringify(seed));return structuredClone(seed)}return JSON.parse(x)}
function saveDB(db){localStorage.setItem(DBKEY,JSON.stringify(db))}
function resetDB(){localStorage.setItem(DBKEY,JSON.stringify(seed));location.reload()}
function money(n){return '₹'+Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}
function user(){let db=getDB();return db.users.find(u=>u.id===localStorage.getItem('sessionUser'))}
function requireAuth(role){const u=user();if(!u){location.href='login.html';return null}if(role&&u.role!==role){location.href=u.role==='admin'?'admin.html':'dashboard.html';return null}return u}
function logout(){localStorage.removeItem('sessionUser');location.href='login.html'}
function toast(msg,type='info'){const el=document.createElement('div');el.className='toast';el.textContent=(type==='success'?'✓ ':type==='error'?'✕ ':'')+msg;document.body.appendChild(el);setTimeout(()=>el.remove(),3000)}
function icon(name){return `<i class="fa-solid fa-${name}"></i>`}
function nav(active,admin=false){
const links=admin?[
['admin.html','gauge-high','Dashboard'],['customers.html','users','Customers'],['accounts.html','building-columns','Accounts'],['transactions.html','arrow-right-arrow-left','Transactions'],['loans.html','hand-holding-dollar','Loans'],['settings.html','gear','Settings'],['reports.html','chart-column','Reports']
]:[
['dashboard.html','gauge-high','Dashboard'],['accounts.html','building-columns','Accounts'],['transfer.html','paper-plane','Transfer Money'],['transactions.html','receipt','Transactions'],['cards.html','credit-card','Cards'],['loans.html','hand-holding-dollar','Loans'],['profile.html','user','Profile'],['security.html','shield-halved','Security'],['notifications.html','bell','Notifications'],['support.html','headset','Support'],['settings.html','gear','Settings']
];
return `<aside class="sidebar" id="sidebar"><div class="brand"><span class="logo">N</span> NovaBank</div><div class="nav-section">${admin?'Administration':'Banking'}</div>${links.map(l=>`<a class="nav-link ${active===l[2]?'active':''}" href="${l[0]}">${icon(l[1])}<span>${l[2]}</span></a>`).join('')}<div class="nav-section">Session</div><a class="nav-link" href="#" onclick="logout()">${icon('right-from-bracket')}<span>Logout</span></a></aside>`
}
function shell(title,active,content,admin=false){
const u=requireAuth(admin?'admin':undefined);if(!u)return;
document.body.innerHTML=`<header class="topbar"><button class="menu-btn" onclick="document.getElementById('sidebar').classList.toggle('open')">${icon('bars')}</button><div class="brand hide-mobile"><span class="logo">N</span> NovaBank</div><div style="display:flex;align-items:center;gap:14px"><button class="btn btn-outline btn-sm" onclick="toggleTheme()">${icon('moon')}<span class="hide-mobile">Theme</span></button><a href="${admin?'admin.html':'notifications.html'}" class="btn btn-outline btn-sm">${icon('bell')}</a><span class="muted hide-mobile">${u.name}</span></div></header><div class="layout">${nav(active,admin)}<main class="main animate">${content}</main></div><div id="modal-root"></div>`;
applyTheme();
}
function toggleTheme(){let db=getDB();db.settings.theme=db.settings.theme==='dark'?'light':'dark';saveDB(db);applyTheme()}
function applyTheme(){document.documentElement.dataset.theme=getDB().settings?.theme||'light'}
function openModal(title,body){document.getElementById('modal-root').innerHTML=`<div class="modal-backdrop" onclick="if(event.target===this)closeModal()"><div class="modal"><div class="modal-head"><h3>${title}</h3><button class="close" onclick="closeModal()">×</button></div><div style="margin-top:18px">${body}</div></div></div>`}
function closeModal(){document.getElementById('modal-root').innerHTML=''}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function uid(prefix){return prefix+Math.random().toString(36).slice(2,8).toUpperCase()}
