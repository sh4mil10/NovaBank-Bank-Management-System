
function chart(id,type,labels,datasets){
const ctx=document.getElementById(id);if(!ctx||typeof Chart==='undefined')return;
return new Chart(ctx,{type,data:{labels,datasets},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{labels:{color:getComputedStyle(document.documentElement).getPropertyValue('--text')}}},scales:type==='doughnut'?{}:{x:{ticks:{color:'#64748b'},grid:{display:false}},y:{ticks:{color:'#64748b'},grid:{color:'rgba(100,116,139,.12)'}}}}});
}
