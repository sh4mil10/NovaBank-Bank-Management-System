
document.addEventListener('DOMContentLoaded',()=>{
const form=document.getElementById('loginForm');if(!form)return;
document.getElementById('togglePass').onclick=()=>{const p=document.getElementById('password');p.type=p.type==='password'?'text':'password'};
document.getElementById('demoCustomer').onclick=()=>{email.value='customer@bank.com';password.value='Customer@123'};
document.getElementById('demoAdmin').onclick=()=>{email.value='admin@bank.com';password.value='Admin@123'};
form.onsubmit=e=>{e.preventDefault();const db=getDB(),u=db.users.find(x=>x.email.toLowerCase()===email.value.trim().toLowerCase()&&x.password===password.value);if(!u)return toast('Invalid credentials','error');if(u.status==='Suspended')return toast('This account is suspended','error');localStorage.setItem('sessionUser',u.id);location.href=u.role==='admin'?'admin.html':'dashboard.html'}
});
