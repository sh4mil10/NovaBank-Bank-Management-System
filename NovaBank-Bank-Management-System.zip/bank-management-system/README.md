# NovaBank — Bank Management System

Competition-ready frontend demo built with HTML5, CSS3, JavaScript, Chart.js, Font Awesome and LocalStorage.

## Run
No build step is required.
1. Open this folder in VS Code.
2. Use Live Server on `index.html` OR run `python -m http.server 5500`.
3. Visit `http://localhost:5500`.

## Demo credentials
Customer: customer@bank.com / Customer@123
Admin: admin@bank.com / Admin@123

## Notes
- All banking actions are simulated.
- Data persists in browser LocalStorage under `novaBankDB`.
- Reset the demo from Settings.
- CDN assets require internet access when using Font Awesome and Chart.js.
